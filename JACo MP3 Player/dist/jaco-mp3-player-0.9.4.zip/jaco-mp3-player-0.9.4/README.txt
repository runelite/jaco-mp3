JACo MP3 Player
===============

Welcome to the MP3 Player component of the Java Application Core project.

Description
-----------

JACo MP3 Player is a cross platform java mp3 player. Features: very low
CPU usage (~2%), incredible small library (~90KB), doesn't need JMF, easy
to integrate in any application, easy to integrate in any web page (as applet).

Licensing
---------

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free
Software Foundation, either version 3 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
details.

You should have received a copy of the GNU Lesser General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.

Contact
-------

  o For general information visit the project home page at
    http://jacomp3player.sourceforge.net/

  o For development information visit the summary page at
    http://sourceforge.net/projects/jacomp3player/

  o To contact project administrator visit
    http://cristiansulea.entrust.ro/
